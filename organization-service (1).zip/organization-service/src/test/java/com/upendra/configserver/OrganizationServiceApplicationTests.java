package com.upendra.configserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
